m.attach({
    thumb: '#thumb',
    large: 'watch6.jpg',
    largeWrapper: 'preview'
});